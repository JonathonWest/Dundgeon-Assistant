# By Andrew Sass
import random

class Dice:
    def __init__(self,numDice, numSide): # type of dice and number of dice
        self.numDice = numDice
        self.numSide = numSide

    def Roll(self):
        ret = 0
        rolls = []
        for i in range (self.numDice):# rolls number of dice
            random_number = random.randint(1, self.numSide)
            ret += random_number
            rolls.append(random_number)
        return rolls

