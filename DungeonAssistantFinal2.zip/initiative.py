#code to set initiative of monsters and players
#once set tracks initiative order and gives the next 2 initiatives when you press next

class Initiative:
    def __init__(self):
        self.initiative = []
      


    def add(self,name,rol): # adds name with value roll to the initiative
      roll = int(rol)
      
      if (len(self.initiative)==0): # if empty jsut add at start
        self.initiative = [[name,roll]]
        return True

      for x in self.initiative: # make sure no conflicting rolls
        if(x[1]==roll):
          return False # if so pass to bot code to deal with it
      if (roll > self.initiative[0][1] ): # if larger than start, insert at head
        self.initiative.insert(0, [name, roll])
        return True

      for i in range (len(self.initiative)): # go through list, add at spot where its bigger than next
        if (roll > self.initiative[i][1]):
          self.initiative.insert(i,[name, roll])
          return True
      
      self.initiative.append([name, roll]) #if never added, goes at the end
      return True


      

    def findAllInits(self,number): # returns list of all items with same initiative
      ret_li = []

      for i in range(len(self.initiative)):
        if int(self.initiative[i][1]) == number:
          ret_li.append(self.initiative[i])
      return(ret_li)



      for x in self.initiative:
        if(x[1]==number):
          ret_li.append(x)

      return (ret_li)


  
    def InsertMatches(self,match_list): # inserts sorted same list at proper position

      new_list = []
      added = True
      for x in range (len(self.initiative)):
        if(self.initiative[x][1]==match_list[0][1]):
          if (added):
            added = False
            for y in match_list:
              new_list.append(y)
        else:
          new_list.append(self.initiative[x])
          
      self.initiative = new_list 
      return True
      
  
    def clear(self): # clears list
      self.initiative = []
      return True

    def remove(self,name): # removes name from the initiative
      for i in range(len(self.initiative)):
        if self.initiative[i][0] == name:
          self.initiative.pop(i)
          return True
      return False

    def showList(self):
      if (len(self.initiative)==0):
        return ("Initiative order is Empty, please add a name") # self explanitory
      if (len(self.initiative)==1):
        return ("Only Member of Initative is: "+self.initiative[0][0])
      ret_str = ""

      for x in range (len(self.initiative)):
        ret_str += ("\n"+self.initiative[x][0]+ ": "+str(self.initiative[x][1]))

      return ret_str

    def next(self): # prints current player, next, and one after
      if (len(self.initiative)==0):
        return ("Initiative order is Empty, please add a name")
      if (len(self.initiative)==1):
        return ("Only Member of Initative is: "+self.initiative[0][0])
      if (len(self.initiative)==2):
        return ("Current turn: "+self.initiative[0][0]+"\nUp next: "+self.initiative[1][0])
      if (len(self.initiative)>2):
        ret_str = ("Current turn: "+self.initiative[0][0]+"\nUp next: "+self.initiative[1][0]+"\nAfter them: "+self.initiative[2][0])
        first_element = self.initiative.pop(0)
        self.initiative.append(first_element)
        return ret_str #returns string to be printed

if __name__ == '__main__':
    #temp = input("What do you want to know about?")
    
    

    init = Initiative()
    init.add("test13",9)
    init.add("test",10)
    init.add("test2",11)
    init.add("test3",12)
    print(init.showList())