import settings
import discord
from discord.ext import commands
import asyncio
import os

import DiceRoller as dr
import question
import initiative as initi
import question
import dungeon as dg
import monster as mon
import npcMake
import itemGen as ig


def run():
  # Get bot ready to roll
    intents = discord.Intents.default()
    intents.message_content = True
    bot = commands.Bot(command_prefix= "d!", intents = intents)
    client = discord.Client(intents=intents)

    @bot.event
    async def on_ready():
        print(f'{client.user} has connected to Discord!')

    @bot.command()
    async def ping(ctx):
        await ctx.send("pong")

    @bot.command()
    async def kill(ctx):
        valk = 2/0
        await ctx.send("pong")
    
    @bot.command()
    async def dice(ctx, *msg):
        await ctx.send("Enter the number of rolls and number of sides, separated by a space (number d[number]).")

        def check(msg):
            str_1 = msg.content.split(" ")[0]
            str_2 = msg.content.split(" ")[1]
            # Checks that user input is in correct format
            return (msg.author == ctx.author and msg.channel == ctx.channel) and \
               (str_1.isdigit() and (str_2[:1] == "d" and str_2[1:].isdigit()))

        dice_stuff = await bot.wait_for("message", check=check)

        # Gets only the numbers from user input
        dice_data = [int(dice_stuff.content.split(" ")[0]), int(dice_stuff.content.split(" ")[1][1:])]

        # Makes sure that dice requests are reasonable
        # so bot doesn't get stuck
        if (dice_data[0] > 200):
            await ctx.send(f"{dice_data[0]} > 200: Too many dice rolls.")
            return
        elif (dice_data[0] == 0):
            await ctx.send("0: Too little dice rolls.")
            return
        elif (dice_data[1] > 10000):
            await ctx.send(f"{dice_data[1]} > 10,000: Too many dice sides.")
            return
        elif (dice_data[1] == 0):
            await ctx.send("0: Too little dice sides.")
            return
       # print(dice_data[0])
        #print(dice_data[1])

        die = dr.Dice(int(dice_data[0]),int(dice_data[1]))
        result = die.Roll()
        result_str = "Result is " + str(result)

        die = dr.Dice(dice_data[0], dice_data[1]).Roll()
        result = die[0]
        result_str = "Result is " + str(die[0])

        # Creates output string
        for i in range(len(die)-1):
            result += die[i+1]
            result_str += " + " + str(die[i+1])

        result_str += f" = {result}."

        await ctx.send(result_str)
     
    

    @bot.command()
    async def ask(ctx):

        # Gets input from user
        await ctx.send("Enter race/class/spell/feat:")

        def check(msg):
            return (msg.author == ctx.author and msg.channel == ctx.channel) 
          
        ques = await bot.wait_for("message", check=check)
        ques = ques.content
      
        #response.content
        
        query = question.Question(ques)
        # Use Question class to figure out what it is and find information
        await ctx.send(query.search())

    @bot.command()
    async def dungeon(ctx):
        dg.generate_dungeon()
        current_directory = os.getcwd()
        with open(os.path.join(current_directory, 'dungeon.png'), "rb") as grid:
            f = discord.File(grid, filename="dungeon.png")    
        # Send dungeon picture file
        await ctx.send(file=f)
      
    @bot.command()
    async def monster(ctx):

        # Get user input
        await ctx.send("Enter the name of a monster.")

        def check(msg):
            return (msg.author == ctx.author and msg.channel == ctx.channel) 

        ques = await bot.wait_for("message", check=check)
        ques = ques.content

        # Use Monster class to get a link to DnD website page
        beast = mon.Monster(ques)
        await ctx.send(beast.search())
      
        #response.content
    
    initiative_list = initi.Initiative()

    @bot.command()
    async def add(ctx, name, roll):
        # Checks that roll is actually an integer
        if roll.isdigit():
            if (initiative_list.add(name, roll)):
                await ctx.send("Initiative added.")
            else:
                # Call findAllInits
                all_inits = initiative_list.findAllInits(int(roll))
                print(all_inits)
                all_inits.append([name, roll])

                print(all_inits)
                print(all_inits[0])
                print(all_inits[0][0])

                # If there are multiple instances of items with this name
                if (len(all_inits) == 2):
                    conflict_str = f"Conflict detected between {all_inits[0][0]} and {all_inits[1][0]}."
                else:
                    # Create informative string about conflict
                    conflict_str = "Conflict detected between "
                    for i in range(len(all_inits)):
                        if i == len(all_inits) - 1:
                            conflict_str += f"and {all_inits[i][0]}. Resolving process begun."
                        else:   
                            conflict_str += str(all_inits[i][0]) + ", "

                await ctx.send(conflict_str)

                # Request all dexts to resolve the conflict
                dex_and_init = []

                for init in all_inits:
                    await ctx.send(f"What is the dexterity stat for {init[0]}?")

                    def check(msg):
                        return (msg.author == ctx.author and msg.channel == ctx.channel) \
                                and msg.content.isdigit()
                    
                    try: 
                        dexterity = await bot.wait_for("message", check=check, timeout=60)
                    except asyncio.TimeoutError:
                        await ctx.send("Bruh why'd you take so long to respond, start over")
                        return
                    
                    dex_and_init.append([int(dexterity.content), init])
                # Create sorted list
                dex_and_init = sorted(dex_and_init, key = lambda x: x[0], reverse=True)
                sorted_inits = [x[1] for x in dex_and_init]

                initiative_list.InsertMatches(sorted_inits)

                await ctx.send("Conflict resolved; initiatives added.")
        else:
            await ctx.send("Invalid initiative roll.")

    @bot.command()
    async def clear(ctx):
        # Clear initiative
        initiative_list.clear()
        await ctx.send("Initiatives cleared.")

    @bot.command()
    async def remove(ctx, name):
        # Check if name in initiative
        if (initiative_list.remove(name)):
            # If so, remove
            await ctx.send("Name removed from initiatives.")
        else:
            # Else, say that GeorgeNotFound
            await ctx.send("Failed; name not found in initiatives.")

    @bot.command()
    async def next(ctx):
        # Gets turn from initiative and progresses it to to next one
        await ctx.send(initiative_list.next())

    @bot.command()
    async def initiative(ctx):
        # Call the function that prints all of the initiatives
        await ctx.send(initiative_list.showList())


    # NPC object
    new_npc = None
    dnd_races = ["Aasimar","Dragonborn","Dwarf","Elf","Firbolg","Genasi","Gnome","Goblin","Goliath","Half-Elf","Half-    Orc","Halfling","Hobgoblin","Human","Kenku","Kobold","Lizardfolk","Orc","Tabaxi","Tiefling","Tortle","Triton","Yuan-ti-Pureblood"]
    classes = ["Artificer","Barbarian","Bard","Cleric","Druid","Fighter","Monk","Paladin","Ranger","Rogue","Sorcerer","Warlock","Wizard"]

    @bot.command()
    async def npc(ctx):
        global new_npc

        await ctx.send("Enter your new NPC's level, class, and race in 1 message.")
        # Make sure format is correct
        def check(msg):
            return (msg.author == ctx.author and msg.channel == ctx.channel) \
            and (len(msg.content.split(" ")) >= 3 and msg.content.split()[0].isdigit())
        
        try: 
            response = await bot.wait_for("message", check=check, timeout=60)
        except asyncio.TimeoutError:
            await ctx.send("Bruh why'd you take so long to respond, start over")
            return

        # Save original for future split use
        original = response.content
        response = response.content.split(" ")
        if (int(response[0]) < 1 or int(response[0]) > 20):
            await ctx.send("Invalid level; must be between 1 and 20 inclusive.")
            return
        # Check if race and class are within list of valid ones
        elif (response[1].title() not in classes):
            await ctx.send("Invalid class.")
            return
        elif (response[2].title() not in dnd_races):
            # Check if race has two parts (half orc)
            if response[2][0] == '"':
                response[2] = original.split('"')[1]
                sep = response[2].split(" ")
                # Convert to dashed form
                response[2] = sep[0].title() + "-" + sep[1].title()
                if response[2] not in dnd_races:
                    await ctx.send("Invalid race.")
                    return
            else:
                await ctx.send("Invalid race.")
                return
        # Make NPC and generate string
        new_npc = npcMake.NPC(response[0], response[1], response[2])

        await ctx.send(new_npc.getStr())
      
    @bot.command()
    async def item(ctx):
        # Use ItemGen class to generate an item
        generator = ig.ItemGen()
        await ctx.send(generator.generateItem())
    
    hbag = []

    # Bag has 3 sub-commands, add, remove, and contents.
    @bot.command()
    async def bag(ctx, type, item=None):
        if (type == "add"):
            hbag.append(item)
            await ctx.send("Item added.")
        elif (type == "remove"):
            try:
                hbag.remove(item)
                await ctx.send("Item removed.")
            # If error, item isn't in bag and tell user.
            except ValueError:
                await ctx.send("Item not found.")
        elif (type == "contents"):
            for item in hbag:
                await ctx.send(item)

    bot.remove_command("help")

    @bot.command(name="help")
    async def _help(ctx):
        # Send help string
        await ctx.send(
""" 
If any response is more than one word, please surround it with quotes.

d!help: Shows this list of available commands
d!dice: Prompts you for num1 d[num2], and generates a series of num1 dice rolls using a die with num2 sides
d!ask: Prompts you for a race/class/spell/feat and gets an informative link to the DnD website
d!dungeon: Randomly generates a picture of a dungeon grid
d!npc: Prompts you for a level, class, and race in order to generate an NPC
d!generate: Generates an random item
d!monster: Prompts you for a monster and then gets an informative link to the DnD website

Initiatives
    d!add name roll: Adds the name and the roll to the initiatives list
    d!next: Gets the next person whose turn it is
    d!remove name: Removes the individual with this name from the initiatives list
    d!clear: Clears the entire initiatives list
    d!initiative: Shows all of the initiatives in the list

Bag of Holding
    d!bag add item: Adds item to bag
    d!bag remove item: Removes item from bag if it's found
    d!bag contents: Displays contents of bag
"""
    )


    bot.run(settings.DISCORD_API_SECRET)

if __name__ == '__main__':
    run()