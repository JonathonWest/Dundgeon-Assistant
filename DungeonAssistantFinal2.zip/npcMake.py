import random


#create dictionaries for every class with 2 high 2 mid and 2 low stat priorities
#we will use this later for generating the stats for npcs
roguedict = {'str':"low","dex":"high",'con':"mid",'int':"high","wis":"low",'cha':"mid"}
fighterdict = {'str':"high","dex":"mid",'con':"high",'int':"mid","wis":"low",'cha':"low"}
barbariandict = {'str':"high","dex":"mid",'con':"high",'int':"low","wis":"low",'cha':"mid"}
barddict = {'str':"low","dex":"high",'con':"mid",'int':"mid","wis":"low",'cha':"high"}
clericdict = {'str':"mid","dex":"low",'con':"high",'int':"mid","wis":"high",'cha':"low"}
druiddict = {'str':"low","dex":"high",'con':"mid",'int':"high","wis":"low",'cha':"mid"}
monkdict = {'str':"mid","dex":"high",'con':"low",'int':"mid","wis":"high",'cha':"low"}
paladindict = {'str':"high","dex":"low",'con':"mid",'int':"low","wis":"mid",'cha':"high"}
rangerdict = {'str':"mid","dex":"high",'con':"low",'int':"low","wis":"high",'cha':"mid"}
sorcererdict = {'str':"low","dex":"high",'con':"mid",'int':"mid","wis":"low",'cha':"high"}
warlockdict = {'str':"mid","dex":"high",'con':"low",'int':"mid","wis":"low",'cha':"high"}
wizarddict = {'str':"low","dex":"high",'con':"mid",'int':"high","wis":"mid",'cha':"low"}
artificerdict = {'str':"low","dex":"high",'con':"mid",'int':"high","wis":"low",'cha':"mid"}

#class for generating NPCs with stats, attacks, spells(if applicable), speed, and AC
#this is generated based on a given class, race, and player level
class NPC:
    def __init__(self, level, pclass, race):
      self.race = race.title()
      self.level = level #given
      self.spells = []
      self.stats = {'str':10,"dex":10,'con':10,'int':10,"wis":10,'cha':10} #DONE
      self.inv = {} # depends on class
      self.attacks = {} # depends on inv randomizer still needed
      self.save_throw = {} # depends on class
      self.ac =0 # depends on armor/dex
      self.speed = 30
      self.hp = 0 # can be calculated
      self.size = "medium"
      self.statDict ={}
      self.pclass =pclass
      
      pclass = pclass.title()
      self.pclass =pclass
      
      #set the stat dictionary to the one corosponding to its class
      if pclass == "Rogue":
        self.statDict = roguedict
      if pclass == "Fighter":
        self.statDict = fighterdict
      if pclass == "Barbarian":
        self.statDict = barbariandict
      if pclass == "Bard":
        self.statDict = barddict
      if pclass == "Cleric":
        self.statDict = clericdict
      if pclass == "Paladin":
        self.statDict = paladindict
      if pclass == "Monk":
        self.statDict = monkdict
      if pclass == "Ranger":
        self.statDict = rangerdict
      if pclass == "Sorcerer":
        self.statDict = roguedict
      if pclass == "Druid":
        self.statDict = druiddict
      if pclass == "Sorcerer":
        self.statDict = sorcererdict
      if pclass == "Wizard":
        self.statDict = wizarddict
      if pclass == "Warlock":
        self.statDict = warlockdict
      if pclass == "Artificer":
        self.statDict = artificerdict
        

    #sets the size and speed of the NPC(based on given race)
    def Size(self):
      race = self.race
      
      #lists of all medium small and large races respectively
      Medium= ["Aasimar","Dragonborn","Dwarf","Elf","Firbolg","Genasi","Half Elf","Half     Orc","Hobgoblin","Human","Kenku","Lizardfolk","Orc","Tabaxi","Tiefling","Tortle","Triton","Yuan-ti-Pureblood"]
      Small = ["Gnome","Goblin","Halfling","Kobold"]
      Large = ["Goliath","Firbolg"]

      #sets size and speed if speed is difrent than default speed
      if (race in Large):
        self.size = "Large"
      elif (race in Medium):
        self.size = "Medium"
        if (race == "Dwarf"):#special case for Dwarfs
          self.speed = 25
      elif (race in Small):
        self.size = "Small"
        self.speed = 25


    #Assigns stats based on level and the allocation dictionary
    def statass(self,list):
      #input list in format H, H, M, M, L, L

      #create random numbers corosponding to list indexes for high mid and low stats
      randHigh = random.randint(0,1)
      randMid = random.randint(2,3)
      randLow = random.randint(4,5)
     
      statDict = self.statDict
     

      for stat in statDict:
        if statDict[stat] == "high": #take one of the high values and set it to that stat
          #place in dict = list[rand]
          statDict[stat] = list[randHigh]
          
          if randHigh == 1: #change the random value to the other one
            randHigh = 0
          else:
            randHigh = 1
            
        elif statDict[stat]== "mid": #take one of the mid values and set it to that stat
          #place in dict = list[rand]
          statDict[stat] = list[randMid]
         # print(randMid)
          
          if randMid == 2: #change the random value to the other one
            randMid = 3
          else:
            randMid = 2
            
        elif statDict[stat] == "low": #take one of the low values and set it to that stat
          #place in dict = list[rand]
          statDict[stat] = list[randLow]
          
          if randLow == 4: #change the random value to the other one
            randLow = 5
          else:
            randLow = 4
      return statDict
          
      

     # returns a list of 6 numbers in the pattern H, H, M, M, L, L
    def RandomList(self):
     
      array= [15,14,13,12,8,10] # Standard Array of DND Stats

      imp = [4,8,12,16,19,20,20] # levels at which stat score increases
      counter = 0
      for x in imp:
        if (int(self.level)>=x):
          counter+= 1 # counts how many times a stat score will increase while generating NPC

      for i in range (counter):
        rand = random.randint(1, 100) #random number

        if (rand<=15): # 15 percent chance of raising 'low' stat
          ran2=random.randint(4,5)
          array[ran2]+=2
        elif (rand<=45):# 30 percent chance of raising 'mid' stat
          ran2=random.randint(2,3)
          array[ran2]+=2 
        else:
          ran2=random.randint(0,1)# 55 percent chance of raising 'high' stat
          array[ran2]+=2
          
      return array # returns array


    #gives an armor class to npc based on class
    def armor(self):
      self.ac = 10#default value
      dex=self.statDict['dex']

      #find and add modifier based on dex
      num = dex - 10
      num = int(num /2)
      self.ac+=  num

      #mod based on class
      if(self.pclass=='Barbarian'):
        self.ac+=self.mod('con')
      if(self.pclass=='Monk'):
        self.ac+=self.mod('wis')
      if(self.pclass=='Fighter'):
        self.ac+=4
      if(self.pclass=='Paladin'):
        self.ac+=4
      if(self.pclass=='Cleric'):
        self.ac+=2
      if(self.pclass=='Ranger'):
        self.ac+=2


    #mod for support with armor class
    def mod(self,stat): # returns modifier for the  stat
      con=self.statDict[stat]
      num = con - 10
      num = int(num /2)
      cmod=  num
      return cmod # modifier is roughly num-10/2


    #assigns weapons(with descriptions) to the NPC
    def Weapon(self):

      #if the class is gets the weapon add it to teh attack dict
      #also gives descriptions for every weapon
      if(self.pclass in('Fighter' , 'Paladin')):
        self.attacks.update({'Longsword':'to hit str + prof bonus range 5ft.: hit(1d4 + str)slashing damadge'})
        
      if(self.pclass in('Fighter' , 'Ranger' )):
        self.attacks.update({'Longbow':'to hit dex + prof bonus range 5ft.: hit(1d8 + dex)piercing damadge'})

      if self.pclass in ('Ranger', 'Rogue', 'Bard'):
        self.attacks.update({'Shortsword':'to hit dex + prof bonus range 5ft.: hit(1d6 + dex)piercing damadge'})

      if(self.pclass=='Barbarian'):
        self.attacks.update({'Greataxe':'to hit str + prof bonus range 5ft.: hit(1d12 + str)slashing damadge'})

      if(self.pclass=='Cleric'):
        self.attacks.update({'Mace':'to hit str + prof bonus range 5ft.: hit(1d6 + str)bludegoning damadge'})

      if(self.pclass in ('Druid' , 'Monk')):
        self.attacks.update({'Quarterstaff':'to hit str + prof bonus range 5ft.: hit(1d6 + str one handed) or (1d8 + str two handed)bludegoning damadge'})

      if(self.pclass in ('Paladin' , 'Barbarian')):
        self.attacks.update({'Javelin':'to hit str + prof bonus range 5ft.: hit(1d8 + str)piercing damadge'})
        
      if(self.pclass in ('Wizard' , 'Warlock' , 'Sorcerer' , 'Rogue' , "Artificer")):
        self.attacks.update({'dagger':'to hit dex + prof bonus range 5ft.(150/600ft. if thrown): hit(1d4 + dex)piercing damadge'})

      if(self.pclass=='Monk'):
        self.attacks.update({'Unarmed Strike':'to hit str + prof bonus range 5ft.: hit(1d4 + str)bludegoning damadge'})

      if(self.pclass=='Artificer'):
        self.attacks.update({'Bomb(Recharge six)':'Launch a small bomb within 30 feet. Each creature within 5 feet of it makes a DC13 (+1 for every 5 levels the artifcer is) Saving throw taking (2d6 for every 5 levels the artificer is) damadge on a failed save and half as much on a sucessful one.'})
      
      return self.attacks


    #Generats a list of spells that each class would have based on class and level
    def Spells(self):
      num = ((int(self.level) - 1) // 3) 
      lv= int(self.level)# how many spells the NPC gets based on level
      num = 6
      if(lv<16):
        num=5
      if(lv<13):
        num=4
      if(lv<10):
        num=3
      if(lv<7):
        num=2
      if(lv<4):
        num=1

      wizardSpell = [["Fire Bolt", "Ice Knife", "Magic Missile"],["Misty_Step","Fireball","Summon Undead"],["Polymorph","Wall of Fire","Dominate Person"],["Scrying","Chain Lightning","Move Earth"],["Plane Shift","Teleport","Prismatic Spray"],["Clone","Power Word Kill","Time Stop"]]
      if self.pclass=='Wizard':
        
        for i in range (0,num): # selects 1 item from each tier depending on level
          ran2=random.randint(0,2)
          self.spells.append(wizardSpell[i][ran2])

      warlockSpell=[["Magic Stone","Thunderclap","Witch Bolt"],["Charm Person","Darkness","Invisibility"],["Thunderstep","Hypnotic Pattern","Fly"],["Banishment","Hold Person","Scrying"],["EyeBite","Summon Fiend","Conjure Fey"],["Finger of Death", "Feeblemind","True Polymorph"]]
      if self.pclass=='Warlock':
      
        for i in range (0,num):
          ran2=random.randint(0,2)# selects 1 item from each tier depending on level
          self.spells.append(warlockSpell[i][ran2])
      
      sorcererSpell=[["Fire Bolt","Chaos Bolt","Ray of Frost"],["Darkness","Dragons Breath","Fireball"],["Ice Storm", "Dimension Door","Cone of Cold"],["Dominate Person","Wall of Light","Sunbeam"],["Fire Storm", "Teleport", "Earthquake"],["Time Stop","Gate","Sunburst"]]
      if self.pclass=='Sorcerer':
        
        for i in range (0,num):
          ran2=random.randint(0,2)# selects 1 item from each tier depending on level
          self.spells.append(sorcererSpell[i][ran2])
      rangerSpell=[["","",""],["Hunters Mark","Hunters Mark","Hunters Mark"],["Gust of Wind","Magic Weapon","Spike Growth"],["Plant Growth","Flame Arrows","Wind Wall"],["Locate Creature","Stoneskin","Locate Creature"],["Conjure Volley","Swift Quiver", "Tree Stride"]]
      if self.pclass=='Ranger':
      
        for i in range (0,num):
          ran2=random.randint(0,2)# selects 1 item from each tier depending on level
          self.spells.append(rangerSpell[i][ran2])
      paladinSpell=[["","",""],["Searing Smite","Thunderous Smite","Wrathful Smite"],["Lesser Restoration","Cure Wounds","Find Steed"],["Blinding Smite","Remove Curse","Revivify"],["Banishment","Locate Creature","Staggering Smite"],["Banishing Smite","Raise Dead","Destructive Wave"]]
      if self.pclass=='Paladin':
       
        for i in range (0,num):
          ran2=random.randint(0,2)# selects 1 item from each tier depending on level
          self.spells.append(paladinSpell[i][ran2])
      druidSpell=[["Shillelagh","Thunderclap","Cure Wounds"],["Entangle","Earthbind","Moonbeam"],["Flaming Sphere","Erupting Earth","Flaming Sphere"],["Sleet Storm","Summon Fey","Ice Storm"],["Heal","Whirlwind","Fire Storm"],["Shapechange","Sunburst","Earthquake"]]
      if self.pclass=='Druid':
        
        for i in range (0,num):
          ran2=random.randint(0,2)# selects 1 item from each tier depending on level
          self.spells.append(druidSpell[i][ran2])
      clericSpell=[["Sacred Flame","Toll the Dead","Healing Word"],["Cure Wounds","Cure Wounds","Guiding Bolt"],["Lesser Restoration","Spiritual Weapon","Hold Person"],["Glyph of Warding","Mass Healing Word","Death Ward"],["Greater Restoration","Holy Weapon","Heal"],["Fire Storm","Holy Aura","Mass Heal"]]
      if self.pclass=='Cleric':
       
        for i in range (0,num):
          ran2=random.randint(0,2)# selects 1 item from each tier depending on level
          self.spells.append(clericSpell[i][ran2])
      bardSpell=[["Minor Ilusion","Vicious Mockery","Color Spray"],["Heat Metal","Hold Person","Invisibility"],["Fast Friends","Dispel Magic","Polymorph"],["Greater Invisibility","Greater Restoration","Legend Lore"],["True Seeing","Mass Suggestion","Teleport"],["Mind Blank","Feeblemind","Power Word Heal"]]
      if self.pclass=='Bard':
        
        for i in range (0,num):
          ran2=random.randint(0,2)# selects 1 item from each tier depending on level
          self.spells.append(bardSpell[i][ran2])

      ArtificerSpell=[["","",""],["Fire Bolt","Grease","Arcane Weapon"],["Faerie Fire","Heat Metal","Magic Weapon"],["Rope Trick","Enlarge/Reduce","Invisibility"],["Haste","Stoneskin","Fly"],["Wall of Stone","Greater Restoration","Stone Shape"]]
      if self.pclass=='Artificer':
       
        for i in range (0,num):
          ran2=random.randint(0,2)# selects 1 item from each tier depending on level
          self.spells.append(ArtificerSpell[i][ran2])
#gets total health based on class and level
    def Health(self):
      dice = {'Artificer':8,"Bard":8,'Cleric':8,'Druid':8,'Monk':8,'Rogue':8,'Warlock':8,'Fighter':10,'Ranger':10,'Paladin':10,'Barbarian':12,'Sorcerer':10,'Wizard':10,} # finds class hit die
      hp = dice.get(self.pclass)
      di = hp
      con=self.statDict['con']
      num = con - 10
      num = int(num /2)
      cmod=  num
      if (self.level == "1"): # level one is hit die max+ con
        return hp+cmod
      for i in range (2,int(self.level)):
        hp += (di/2)+1+cmod # each level, adds avg hit die + con
      return hp
      
      
    
    def stats(self):# this is my SUPER janky way of randomizing stats for NPCS
      #step 1: determine value for total number stats will be adjusted
      change = self.level #for now lets just do the level

      for i in range (change):
        random_stat,random_val = random.choice(list(self.stats.items())) # select a random stat, value not used but needed for command
        self.stats[random_stat] = self.stats[random_stat] + 1 # stat is raised by one
         #method may make stats go over 20 but it works so f off

    
    #returns modifier for stat
    def get_mod(self,num):# returns modifer for stat int
      num = num - 10
      num = num %2
      return num
      
    # converts NPC to string for printing
    def getStr(self):
      #print (self.statDict)
      statlist = self.RandomList()
      #print(statlist)
      self.statDict = self.statass(statlist)
      #print(self.statDict)
      self.Size()
      self.armor()
      self.Weapon()
      self.Spells()

      #formating string for output in discord
      rstr = (self.race + " " + self.pclass + ":\n")
      rstr += ("Level: "+self.level+"\n")
      rstr += ("Armor Class: " +str(self.ac)+"\n")
      rstr += ("Hit Points: " + str(self.Health()) + "\n")
      rstr += ("Speed: " + str(self.speed)+ "\n")
      rstr += ("Size: "+ self.size +"\n")
      rstr += ("-----------------------------------------------------------------------\n")
      rstr += ("Str: "+str(self.statDict["str"])+" ("+str(self.mod("str"))+") ")
      rstr += ("Dex: "+str(self.statDict["dex"])+" ("+str(self.mod("dex"))+") ")
      rstr += ("Con: "+str(self.statDict["con"])+" ("+str(self.mod("con"))+") ")
      rstr += ("Int: "+str(self.statDict["int"])+" ("+str(self.mod("int"))+") ")
      rstr += ("Wis: "+str(self.statDict["wis"])+" ("+str(self.mod("wis"))+") ")
      rstr += ("Cha: "+str(self.statDict["cha"])+" ("+str(self.mod("cha"))+")\n")
      rstr += ("-----------------------------------------------------------------------\n")
      for weapon, attack in self.attacks.items():
        rstr += "{}: {}\n".format(weapon, attack)
      rstr += ("-----------------------------------------------------------------------\n")
      if(len(self.spells)>0):
        rstr+=("Spells:\n| ")
        for item in self.spells:
          rstr+= (item+" | ")
      
      return rstr


#main for testing
if __name__ == '__main__':
    dnd_races = ["Aasimar","Dragonborn","Dwarf","Elf","Firbolg","Genasi","Gnome","Goblin","Goliath","Half-Elf","Half-    Orc","Halfling","Hobgoblin","Human","Kenku","Kobold","Lizardfolk","Orc","Tabaxi","Tiefling","Tortle","Triton","Yuan-ti-Pureblood"]
    Classes = ["Barbarian","Bard","Cleric","Druid","Fighter","Monk","Paladin","Ranger","Rogue","Sorcerer","Warlock","Wizard"]

    for c in Classes:
      for race in dnd_races:
        for i in range (1,20):

          np = NPC(str(1),'Bard',race)
          print(np.getStr())
    
