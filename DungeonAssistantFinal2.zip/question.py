class Question:
    def __init__(self,ques):
        self.ques = ques
        self.link ="http://dnd5e.wikidot.com" #prefix of link

    def search(self):
        self.ques = self.ques.title() #handle input a lil
        feet = ['Aberrant Dragonmark', 'Actor', 'Adept of the Black Robes', 'Adept of the Red Robes', 'Adept of the White Robes', 'Alert', 'Artificer Initiate', 'Athlete', 'Charger', 'Chef', 'Crossbow Expert', 'Crusher', 'Defensive Duelist', 'Divinely Favored', 'Dual Wielder', 'Dungeon Delver', 'Durable', 'Eldritch Adept', 'Elemental Adept', 'Fey Touched', 'Fighting Initiate', 'Gift of the Chromatic Dragon', 'Gift of the Gem Dragon', 'Gift of the Metallic Dragon', 'Grappler', 'Great Weapon Master', 'Gunner', 'Healer', 'Heavily Armored', 'Heavy Armor Master', 'Initiate of High Sorcery', 'Inspiring Leader', 'Keen Mind', 'Knight of the Crown', 'Knight of the Sword', 'Knight of the Rose', 'Lightly Armored', 'Linguist', 'Lucky', 'Mage Slayer', 'Magic Initiate', 'Martial Adept', 'Medium Armor Master', 'Metamagic Adept', 'Mobile', 'Moderately Armored', 'Mounted Combatant', 'Observant', 'Piercer', 'Poisoner', 'Polearm Master', 'Resilient', 'Ritual Caster', 'Savage Attacker', 'Sentinel', 'Shadow Touched', 'Sharpshooter', 'Shield Master', 'Skill Expert', 'Skilled', 'Skulker', 'Slasher', 'Spell Sniper', 'Squire of Solamnia', 'Strixhaven Initiate', 'Strixhaven Mascot', 'Tavern Brawler', 'Telekinetic', 'Telepathic', 'Tough', 'War Caster', 'Weapon Master', 'Acrobat', 'Adept of the Black Robes', 'Adept of the Red Robes', 
'Adept of the White Robes', 'Agent of Order', 'Alchemist', 'Animal Handler', 'Arcanist', 'Baleful Scion', 'Blade Mastery', 'Brawny', 'Burglar', 'Cartomancer', 'Cohort of Chaos', 'Diplomat', 'Divine Communications', 'Divinely Favored', 'Dragonmark', 'Elemental Touched', 'Ember of the Fire Giant', 'Ember of the Fire Giant (Revised)', 'Empathic', 'Fell Handed', 'Flail Mastery', 'Fury of the Frost Giant', 'Fury of the Frost Giant (Revised)', 'Guile of the Cloud Giant', 'Guile of the Cloud Giant (Revised)', 'Gourmand', 'Greater Dragonmark', 'Historian', 'Initiate of High Sorcery', 'Investigator', 'Keenness of the Stone Giant', 'Keenness of the Stone Giant (Revised)', 'Knight of the Crown', 'Knight of the Sword', 'Knight of the Rose', 'Master of Disguise', 'Medic', 'Menacing', 'Metabolic Control', 'Naturalist', 'Outlands Envoy', 'Outsized Might', 'Perceptive', 'Performer', 'Planar Wanderer', 'Practiced Expert', 'Quick-Fingered', 'Righteous Heritor', 'Rune Carver Adept', 'Rune Carver Adept (Revised)', 
'Rune Carver Apprentice', 'Rune Carver Apprentice (Revised)', 'Scion of Elemental Air', 'Scion of Elemental Earth', 'Scion of Elemental Fire', 'Scion of Elemental Water', 'Shield Training', 'Silver-Tongued', 'Spear Mastery', 'Squire of Solamnia', 'Soul of the Storm Giant', 'Soul of the Storm Giant (Revised)', 'Stealthy', 'Strike of the Giants', 'Survivalist', 'Tandem Tactician', 'Theologian', 'Tower of Iron Will', 'Tracker', 'Vigor of the Hill Giant', 'Vigor of the Hill Giant (Revised)', 'Wild Talent', 'Servo Crafting', 'Quicksmithing', 'Cruel', 'Flash Recall', 'Mystic Conflux', 'Remarkable Recovery', 'Spelldriver', 'Thrown Arms Master', 'Vital Sacrifice'] 
        
        if(self.ques in feet):
            self.ques = self.ques.replace(" ", "-")
            return(self.link+"/feat:"+self.ques) # is it a feat?
        self.ques = self.ques.replace(" ", "-")
        Classes = ["Artificer","Barbarian","Bard","Cleric","Druid","Fighter","Monk","Paladin","Ranger","Blood-Hunter","Rogue","Sorcerer","Warlock","Wizard"]
        if(self.ques in Classes):
            return(self.link+"/"+self.ques) # is it a class?
        dnd_races = ["Aasimar","Dragonborn","Dwarf","Elf","Firbolg","Genasi","Gnome","Goblin","Goliath","Half-Elf","Half-    Orc","Halfling","Hobgoblin","Human","Kenku","Kobold","Lizardfolk","Orc","Tabaxi","Tiefling","Tortle","Triton","Yuan-ti-Pureblood"]
        if(self.ques in dnd_races):
            return(self.link+"/lineage:"+self.ques) # is it a race/lineage?
        return ("this is probably a spell, if so it is : "+self.link+"/spell:"+self.ques) # if not then its a spell, theres alot of those

if __name__ == '__main__':
    temp = input("What do you want to know about?")
    
    quer = Question(temp)
    print(quer.search())

