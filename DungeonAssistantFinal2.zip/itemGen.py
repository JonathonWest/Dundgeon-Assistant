import random

class ItemGen:
  def __init__(self):
    # Define lists of possible item types, materials, properties, and modifiers
    self.item_types = {
        'weapon': {
            'types': ['shortsword','longsword', 'axe','greataxe', 'mace', 'longbow','shortbow','crossbow', 'dagger', 'staff','lance'],
            'modifiers': ['of fire', 'of ice', 'of lightning', 'of poison', 'of darkness']
        },
        'armor': {
            'types': ['plate', 'chainmail', 'leather armor', 'robe'],
            'modifiers': ['of protection', 'of resistance', 'of agility', 'of health']
        },
        'Jwelrey': {
            'types': ['ring','amulet','necklace','brooch'],
            'modifiers': ['of invisibility', 'of teleportation', 'of regeneration', 'of fire','of wisdom', 'of strength', 'of charisma', 'of endurance']
        },
        'staff': {
            'types': ['staff'],
            'modifiers': ['of disintegration', 'of healing', 'of summoning', 'of transformation']
        },
        'scroll': {
            'types': ['scroll'],
            'modifiers': ['of fireball', 'of lightning bolt', 'of summon monster', 'of invisible','of detect magic', 'of Alarm']
        }
    }

  def generateItem(self):
    # Generate a random item
    item_type = random.choice(list(self.item_types.keys())) #get random type
    item_subtype = random.choice(self.item_types[item_type]['types']) # get random subtype
    modifier = random.choice(self.item_types[item_type]['modifiers']) #  get modifier
    
    return (f"A {item_subtype} {modifier}")  # return item


#main for testing
if __name__ == '__main__':
    string = ItemGen()
    print(string.generateItem())