class Monster:
    def __init__(self,input):
        self.input = input #pastes monster into adress
        self.link = "https://roll20.net/compendium/dnd5e/"
        self.end = "#content"

    #formats string for output of a link to the monster on roll20
    def search(self):
      self.input = self.input.replace(" ", "_") #handle input a smidge
      return ("Here is the page for " + self.input + ": " + self.link + self.input + self.end)

#main for testing
if __name__ == '__main__':
    temp = input("What monster are you looking for?")
    
    mon = Monster(temp)
    print(mon.search())