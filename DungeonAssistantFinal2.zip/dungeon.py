from PIL import Image
import random
import os

pix_size = 14

# Define the dimensions of the image
WIDTH = 500
HEIGHT = 500

# Define the color codes for different parts of the dungeon
WALL_COLOR = (255, 255, 255)
FLOOR_COLOR = (0, 0, 0)

def generate_dungeon():
    # Initialize the image
    img = Image.new('RGB', (WIDTH, HEIGHT), color=FLOOR_COLOR)

    # Set the starting position for the random walk
    x, y = WIDTH // 2, HEIGHT // 2

    # Define the range of possible movements
    movements = [(0, pix_size), (0, -pix_size), (pix_size, 0), (-pix_size, 0)]

    # Define the number of steps for the random walk
    num_steps = 500

    # Generate the random walk
    for i in range(num_steps):
        # Repeat until new position is within the image bounds
        while True:
            # Move in a random direction
            dx, dy = random.choice(movements)
            x += dx
            y += dy

            if (x <= pix_size//2 or x >= (WIDTH - pix_size//2)) or (y < pix_size//2 or y >= (HEIGHT - pix_size//2)):
                x -= dx
                y -= dy
            else:
                # Position is valid, move on
                break

        # If so, color all the pixels at the new position
        for i in range(x - pix_size//2, x + pix_size//2 + 1):
            for j in range(y - pix_size//2, y + pix_size//2 + 1):
                img.putpixel((i, j), WALL_COLOR)

        for i in range(x - pix_size//2, x + pix_size//2 + 1):
            for j in (y - pix_size//2, y + pix_size//2):
                img.putpixel((i, j), FLOOR_COLOR)

        for i in (x - pix_size//2, x + pix_size//2):
            for j in range(y - pix_size//2, y + pix_size//2 + 1):
                img.putpixel((i, j), FLOOR_COLOR)

    # Get the absolute path of the directory where the Python file is located
    dir_path = os.path.abspath(os.path.dirname(__file__))

    # Define the filename for the image
    filename = 'dungeon.png'

    # Save the image in the same folder as the Python file
    img.save(os.path.join(dir_path, filename))